#include "Actor.hpp"

Actor::Actor(sf::Shape& shape, sf::Vector2f position, const std::string& texturePath)
    : Object(shape, position, texturePath) {
}

bool Actor::isTouchingFloor(const sf::Shape& object) {
    sf::FloatRect actorBounds = this->shape.getGlobalBounds();
    sf::FloatRect otherBounds = object.getGlobalBounds();

    // Calc the lower bounds
    float shapeLowerBound = actorBounds.top + actorBounds.height;
    // Calc the upper bounds of obj
    float objectUpperBound = otherBounds.top;
    // Check if the lower bounds of this->shape intersect with the upper bounds of object
    return (shapeLowerBound >= objectUpperBound && actorBounds.intersects(otherBounds));

}

void Actor::moveLeft(float velocity){
    this->shape.move(velocity * -1, 0.f);
    // move(velocity * -1, 0.f);
}
void Actor::moveRight(float velocity){
    // move(velocity, 0.f);
    this->shape.move(velocity, 0.f);
}
