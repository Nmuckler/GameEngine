#include "Physics.hpp"

// float Physics::getDeltaTime() {
//     return clock.restart().asSeconds();
// }