#include "Object.hpp"

Object::Object(sf::Shape& shape, sf::Vector2f position, const std::string& texturePath) : shape(shape), texture(texture) {
    if (texturePath == "") {
        this->shape.setFillColor(sf::Color(250, 0, 0));
    } else if (!texture.loadFromFile(texturePath)) {
        this->shape.setFillColor(sf::Color(250, 0, 0));
    } else {
        this->shape.setTexture(&texture);
    }
    this->shape.setPosition(position);
    positionX = position.x;
    positionY = position.y;
    velocityX = 0;
    velocityY = 0;
}

void Object::draw(sf::RenderWindow& window, bool drawBoundingBox) {
    if (drawBoundingBox) { //shows hit boxes
        sf::FloatRect bounds = shape.getGlobalBounds();
        sf::RectangleShape boundingBox(sf::Vector2f(bounds.width, bounds.height));
        boundingBox.setPosition(bounds.left, bounds.top);
        boundingBox.setOutlineColor(sf::Color::Green);
        boundingBox.setOutlineThickness(1.0f);
        boundingBox.setFillColor(sf::Color::Transparent);
        window.draw(boundingBox);
    }
    window.draw(shape);
}

sf::Shape& Object::getShape() {
    return shape;
}

void Object::move(float velX, float velY){
    // this->shape.setPosition(positionX + velX, positionY + velY);
    // positionX = this->shape.getPosition().x;
    // positionY = this->shape.getPosition().y;
    this->shape.move(velX, velY);
}

// void Object::jump(){
//     velocityY = -10;
// }



/**
 * Taken from
 * https://gamedev.stackexchange.com/questions/29617/how-to-make-a-character-jump/29618#29618
 *
 **/
// void Object::update(){

//     // positionX += velocityX * deltaTime;      // Apply horizontal velocity to X position
//     // positionY += velocityY * deltaTime;      // Apply vertical velocity to X position
//     // move(velocityX, velocityY);
//     // velocityY += gravity * deltaTime;
// }

