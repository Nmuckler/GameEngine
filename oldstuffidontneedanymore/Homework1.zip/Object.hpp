#ifndef OBJECT_HPP
#define OBJECT_HPP

#include <SFML/Graphics.hpp>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>
#include "Physics.hpp"

class Object {
public:
    Object(sf::Shape& shape, sf::Vector2f position, const std::string& texturePath);

    sf::Shape& getShape();

    void draw(sf::RenderWindow& window, bool drawBoundingBox);

    void move(float velX, float velY);

    void jump();

    void update();

protected:
    sf::Shape& shape;
    sf::Texture texture;
    float positionX, positionY;
    float velocityX, velocityY;
    float gravity = 0.5f;
    // float deltaTime = Physics().getDeltaTime();
};

#endif