#include "Actor.hpp"
#include "Object.hpp"
#include "GameObject.hpp"

int main()
{
    // Create a window
    sf::RenderWindow window(sf::VideoMode(800, 600), "Engine Window");
    window.setFramerateLimit(60);
    float moveSpeed = 2;

    bool hitboxActive = false;

    // Create a circle shape
    sf::CircleShape newActorCircle(35.f);

    sf::RectangleShape line(sf::Vector2f(800.f, 5.f));
    sf::RectangleShape movingLine(sf::Vector2f(250.f, 30.f));


    // Create a an Actor
    Actor character = Actor(newActorCircle, sf::Vector2f(100, 100), "hamster.png");
    GameObject floor = GameObject(line, sf::Vector2f(0, 550), "");
    GameObject platform = GameObject(movingLine, sf::Vector2f(600, 550), "");

    //shape.setPosition(400.f, 400.f);

    // Run the program as long as the window is open
    while (window.isOpen())
    {
        // Check all the window's events that were triggered since the last iteration of the loop
        sf::Event event;

        while (window.pollEvent(event))
        {
            // "Close requested" event: we close the window
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }

        //Turn hit boxes on or off
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::H))
        {
            hitboxActive = !hitboxActive;
        }

        //Controls
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
        {
            // Left key is pressed: move our character to the left
            character.moveLeft(moveSpeed);
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
        {
            // Right key is pressed: move our character to the right
            character.moveRight(moveSpeed);
        }
        // if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
        // {
        //     if(character.isTouchingFloor(floor.getShape()) && character.isTouchingFloor(platform.getShape()))
        //         character.jump();
        // }
        // Gravity
        if(!character.isTouchingFloor(floor.getShape()) && !character.isTouchingFloor(platform.getShape())){
            character.getShape().move(0.f, 2.f);
        }

        // Clear the window with white color
        window.clear(sf::Color::White);

        platform.hoverY(200, 550, .5);
        // platform.hoverX(200, 550, .5);

        // character.update();
        // Draw the character
        character.draw(window, hitboxActive);
        floor.draw(window, hitboxActive);
        platform.draw(window, hitboxActive);

        // Display the updated frame
        window.display();
    }

    return EXIT_SUCCESS;
}
