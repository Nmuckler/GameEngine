For compiling and running this program, run these commands after the other:

1. make init
2. make clean
3. make
#I usually run step 4 while step 3 is executing
4. ./main


I will reuse steps 2-4 whenever I want to run the program afterward.

After program is running you can control the actor with the left and right arrow keys.

Credit to for image:
https://www.reddit.com/user/manuadvance/