#ifndef ACTOR_HPP
#define ACTOR_HPP

#include "Object.hpp"

class Actor: public Object {
public:
    Actor(sf::Shape& shape, sf::Vector2f position, const std::string& texturePath);

    bool isTouchingFloor(const sf::Shape& object);

    void moveLeft(float speed);

    void moveRight(float speed);

};

#endif